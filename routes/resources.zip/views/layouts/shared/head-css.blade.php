@vite(['resources/scss/app.scss', 'resources/scss/icons.scss'])
