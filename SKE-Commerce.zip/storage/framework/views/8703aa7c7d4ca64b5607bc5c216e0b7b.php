<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.css'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title">Order Details</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($order->id); ?></td>
                            </tr>
                            <tr>
                                <th>User</th>
                                <td><?php echo e($order->user->name); ?></td>
                            </tr>
                            <tr>
                                <th>Total</th>
                                <td><?php echo e($order->total); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e(ucfirst($order->status)); ?></td>
                            </tr>
                        </table>

                        <h5>Sub Items</h5>
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Price</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $order->subItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderSubItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($orderSubItem->subItem->id); ?></td>
                                    <td><?php echo e($orderSubItem->subItem->name); ?></td>
                                    <td><?php echo e($orderSubItem->price); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-primary">Back to Orders</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.js'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['page_title' => 'Order Details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/admin/orders/show.blade.php ENDPATH**/ ?>