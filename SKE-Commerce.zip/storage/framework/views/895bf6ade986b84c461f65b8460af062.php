<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.css'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Purchase Request Details</h4>
                        <table class="table table-bordered">
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($purchaseRequest->id); ?></td>
                            </tr>
                            <tr>
                                <th>User</th>
                                <td><?php echo e($purchaseRequest->user->name); ?></td>
                            </tr>
                            <tr>
                                <th>Notes</th>
                                <td><?php echo e($purchaseRequest->notes); ?></td>
                            </tr>
                            <tr>
                                <th>Amount</th>
                                <td><?php echo e($purchaseRequest->amount); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo e(ucfirst($purchaseRequest->status)); ?></td>
                            </tr>
                            <tr>
                                <th>Document</th>
                                <td>
                                    <?php if($purchaseRequest->getFirstMediaUrl('purchase_documents')): ?>
                                        <a href="<?php echo e($purchaseRequest->getFirstMediaUrl('purchase_documents')); ?>" target="_blank">View Document</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                        <a href="<?php echo e(route('purchase-requests.index')); ?>" class="btn btn-primary">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.js'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['page_title' => 'Purchase Request Details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/admin/purchase_requests/show.blade.php ENDPATH**/ ?>