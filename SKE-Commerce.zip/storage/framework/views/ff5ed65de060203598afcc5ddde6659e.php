<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.css'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title">Edit Purchase Request</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form id="edit-purchase-request-form" action="<?php echo e(route('purchase-requests.update', $purchaseRequest->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="user_id" class="form-label">User</label>
                                <select class="form-control" id="user_id" name="user_id">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>" <?php echo e($purchaseRequest->user_id == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control" id="notes" name="notes"><?php echo e($purchaseRequest->notes); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="amount" class="form-label">Amount</label>
                                <input type="number" step="0.01" class="form-control" id="amount" name="amount" value="<?php echo e($purchaseRequest->amount); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="status_id" class="form-label">Status</label>
                                <select class="form-control" id="status_id" name="status" required>
                                    <option value="pending" <?php echo e($purchaseRequest->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                    <option value="approved" <?php echo e($purchaseRequest->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                    <option value="rejected" <?php echo e($purchaseRequest->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="purchase_documents" class="form-label">Document</label>
                                <input type="file" class="form-control" id="purchase_documents" name="purchase_documents" accept="image/*">
                                <div class="mt-2" id="document-preview">
                                    <?php if($purchaseRequest->getFirstMediaUrl('purchase_documents')): ?>
                                        <img src="<?php echo e($purchaseRequest->getFirstMediaUrl('purchase_documents')); ?>" alt="Document Preview" style="max-width: 200px;">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.js'
    ]); ?>

    <script>
        $(document).ready(function() {
            $('#purchase_documents').change(function() {
                let reader = new FileReader();
                reader.onload = function(e) {
                    $('#document-preview').html('<img src="' + e.target.result + '" alt="Document Preview" style="max-width: 200px;">');
                }
                reader.readAsDataURL(this.files[0]);
            });

            $('#edit-purchase-request-form').on('submit', function(e) {
                e.preventDefault();

                var formData = new FormData(this);

                $.ajax({
                    url: $(this).attr('action'),
                    method: $(this).attr('method'),
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        $.toast({
                            heading: 'Success',
                            text: 'Purchase request updated successfully.',
                            icon: 'success',
                            loader: true,
                            loaderBg: '#f96868',
                            position: 'top-right',
                            hideAfter: 3000
                        });
                    },
                    error: function(response) {
                        $.toast({
                            heading: 'Error',
                            text: 'There was an error updating the purchase request.',
                            icon: 'error',
                            loader: true,
                            loaderBg: '#f96868',
                            position: 'top-right',
                            hideAfter: 3000
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['page_title' => 'Edit Purchase Request'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/admin/purchase_requests/edit.blade.php ENDPATH**/ ?>