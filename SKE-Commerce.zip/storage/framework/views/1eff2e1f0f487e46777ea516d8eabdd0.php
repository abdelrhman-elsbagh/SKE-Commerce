<?php $__env->startSection('title', 'Ske E-Commerce'); ?>

<?php $__env->startSection('content'); ?>
    <main class="page-main">
        <div class="widjet --filters">
            <div class="widjet__head">
                <h3 class="uk-text-lead">My Favourites</h3>
            </div>
        </div>
        <div class="uk-grid uk-child-width-1-6@xl uk-child-width-1-4@l uk-child-width-1-3@s uk-flex-middle uk-grid-small" data-uk-grid>
            <?php $__empty_1 = true; $__currentLoopData = $userFavorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div>
                    <div class="game-card">
                        <div class="game-card__box">
                            <div class="game-card__media">
                                <a href="<?php echo e(route('item.show', ['id' => $favorite->subItem ? $favorite->subItem->item->id : $favorite->item_id])); ?>">
                                    <?php if($favorite->subItem && $favorite->subItem->getFirstMediaUrl('images')): ?>
                                        <img src="<?php echo e($favorite->subItem->getFirstMediaUrl('images')); ?>" alt="<?php echo e($favorite->subItem->name); ?>">
                                    <?php elseif($favorite->item && $favorite->item->getFirstMediaUrl('images')): ?>
                                        <img src="<?php echo e($favorite->item->getFirstMediaUrl('images')); ?>" alt="<?php echo e($favorite->item->name); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/img/default-image.jpg')); ?>" alt="Default Image">
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="game-card__info">
                                <a class="game-card__title" href="<?php echo e(route('item.show', ['id' => $favorite->subItem ? $favorite->subItem->item->id : $favorite->item_id])); ?>">
                                    <?php echo e($favorite->subItem ? $favorite->subItem->name : $favorite->item->name); ?>

                                </a>
                                <div class="game-card__genre">
                                    <?php echo e($favorite->subItem ? $favorite->subItem->amount : 'N/A'); ?>

                                </div>
                                <div class="game-card__rating-and-price">
                                    <div class="game-card__price">
                                        <span>
                                            $<?php echo e(number_format($favorite->subItem ? $favorite->subItem->price : $favorite->item->price, 2)); ?>

                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="uk-width-1-1">
                    <p>No favourites found.</p>
                </div>
            <?php endif; ?>
        </div>
    </main>
    <?php if(session('success')): ?>
        <?php $__env->startPush('scripts'); ?>
            <script>
                toastr.success("<?php echo e(session('success')); ?>");
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/front/favourites.blade.php ENDPATH**/ ?>