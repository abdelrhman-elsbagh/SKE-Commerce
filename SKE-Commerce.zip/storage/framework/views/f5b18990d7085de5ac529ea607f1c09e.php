<?php $__env->startSection('title', 'Plans'); ?>

<?php $__env->startSection('content'); ?>
    <main class="page-main">
        <div class="uk-container">
            <h1 class="uk-heading-line"><span>Our Plans</span></h1>
            <div class="uk-grid uk-child-width-1-3@m uk-child-width-1-2@s uk-grid-small" data-uk-grid>
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="uk-card uk-card-default uk-card-hover uk-margin plan-card">
                            <div class="uk-card-header uk-text-center">
                                <h3 class="uk-card-title"><?php echo e($plan->name); ?></h3>
                                <p class="uk-text-meta uk-margin-remove-top">$<?php echo e(number_format($plan->price, 2)); ?> / <?php echo e($plan->duration); ?> days</p>
                            </div>
                            <div class="uk-card-body">
                                <p><?php echo e($plan->description); ?></p>
                                <ul class="uk-list uk-list-bullet uk-margin-top">
                                    <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><i class="fas fa-check-circle uk-margin-small-right" style="color: #f46119;"></i><?php echo e($feature->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <div class="uk-card-footer uk-text-center">
                                <a href="#" class="uk-button uk-button-primary">Choose Plan</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </main>

    <style>
        .uk-card-header {
            background-color: #f0f0f0;
            padding: 20px;
            border-bottom: 1px solid #ddd;
        }
        .uk-card-body {
            padding: 20px;
        }
        .uk-card-footer {
            background-color: #f0f0f0;
            padding: 20px;
            border-top: 1px solid #ddd;
        }
        .uk-card-title {
            margin-bottom: 10px;
            font-size: 1.5em;
        }
        .uk-text-meta {
            font-size: 1.2em;
            color: #888;
        }
        .uk-button-primary {
            background-color: #f46119;
            border-color: #f46119;
            color: #fff;
        }
    </style>
<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const cards = document.querySelectorAll('.uk-card-body');
        let maxHeight = 0;

        // Calculate the max height
        cards.forEach(card => {
            const cardHeight = card.offsetHeight;
            if (cardHeight > maxHeight) {
                maxHeight = cardHeight;
            }
        });

        // Set all cards to the max height
        cards.forEach(card => {
            card.style.height = `${maxHeight}px`;
        });
    });
</script>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/front/plans.blade.php ENDPATH**/ ?>