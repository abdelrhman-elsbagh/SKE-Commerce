<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.css'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Slider Details</h4>
                        <table class="table table-bordered">
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($slider->id); ?></td>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <td><?php echo e($slider->name); ?></td>
                            </tr>
                            <tr>
                                <th>Image</th>
                                <td><img src="<?php echo e($slider->getFirstMediaUrl('images')); ?>" alt="<?php echo e($slider->name); ?>" style="max-width: 200px;"></td>
                            </tr>
                        </table>
                        <a href="<?php echo e(route('sliders.index')); ?>" class="btn btn-primary">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.js'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['page_title' => 'Slider Details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/admin/sliders/show.blade.php ENDPATH**/ ?>