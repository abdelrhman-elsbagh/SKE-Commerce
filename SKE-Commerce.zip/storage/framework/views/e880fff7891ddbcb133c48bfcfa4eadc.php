<!-- resources/views/front/payment-methods.blade.php -->



<?php $__env->startSection('title', 'Payment Methods'); ?>

<?php $__env->startSection('content'); ?>
    <main class="page-main">
        <div class="uk-container">
            <h1 class="uk-heading-line"><span>Payment Methods</span></h1>
            <div class="uk-grid uk-child-width-1-3@m uk-child-width-1-2@s uk-grid-small" data-uk-grid>
                <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="uk-card uk-card-default uk-card-hover uk-margin">
                            <div class="uk-card-header">
                                <h3 class="uk-card-title"><?php echo e($method->gateway); ?></h3>
                            </div>
                            <div class="uk-card-body">
                                <p><?php echo e($method->description); ?></p>
                                <?php if($method->getFirstMediaUrl('payment_method_images')): ?>
                                    <img src="<?php echo e($method->getFirstMediaUrl('payment_method_images')); ?>" alt="<?php echo e($method->gateway); ?>" class="uk-width-1-1">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/img/default-image.jpg')); ?>" alt="Default Image" class="uk-width-1-1">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/front/payment-methods.blade.php ENDPATH**/ ?>