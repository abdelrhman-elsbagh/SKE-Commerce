<!-- bundle -->
<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->
<?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/layouts/shared/footer-script.blade.php ENDPATH**/ ?>