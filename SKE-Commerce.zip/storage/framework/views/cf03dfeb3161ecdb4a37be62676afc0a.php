<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.css'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title">Show Payment Method</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($paymentMethod->id); ?></td>
                            </tr>
                            <tr>
                                <th>Gateway</th>
                                <td><?php echo e($paymentMethod->gateway); ?></td>
                            </tr>
                            <tr>
                                <th>Description</th>
                                <td><?php echo e($paymentMethod->description); ?></td>
                            </tr>
                            <tr>
                                <th>Image</th>
                                <td>
                                    <?php if($paymentMethod->getFirstMediaUrl('payment_method_images')): ?>
                                        <img src="<?php echo e($paymentMethod->getFirstMediaUrl('payment_method_images')); ?>" alt="Payment Method Image" style="max-width: 200px;">
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                        <a href="<?php echo e(route('payment-methods.index')); ?>" class="btn btn-primary">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.js'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['page_title' => 'Show Payment Method'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/admin/payment_methods/show.blade.php ENDPATH**/ ?>