<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.shared/title-meta', ['title' => $page_title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->make('layouts.shared/head-css', ['mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Load jQuery directly from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/head.js']); ?>
</head>

<body>
<div class="wrapper">

    <?php echo $__env->make('layouts.shared/topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.shared/left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->

    <div class="content-page">
        <div class="content" id="content">
            <!-- Start Content-->
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('layouts.shared/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->

</div>

<?php echo $__env->make('layouts.shared/right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.shared/footer-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/js/layout.js']); ?>
<?php echo $__env->yieldContent('admin-script'); ?>

<script>
    // $(document).ready(function() {
    //     console.log('Document ready 1');
    //
    //     $(document).on('click', '.nav-link', function(e) {
    //         console.log("nav-link")
    //         e.preventDefault();
    //         var url = $(this).attr('href');
    //         console.log('Navigating to:', url);
    //
    //         history.pushState(null, '', url);
    //
    //         $.ajax({
    //             url: url,
    //             method: 'GET',
    //             success: function(data) {
    //                 console.log('AJAX success:', data);
    //                 $('#content').html($(data).find('#content').html());
    //             },
    //             error: function(xhr) {
    //                 console.error('Error loading page', xhr);
    //             }
    //         });
    //     });
    //
    //     // Handle back/forward navigation
    //     window.onpopstate = function() {
    //         var url = window.location.pathname;
    //         console.log('Popstate event:', url);
    //         $.ajax({
    //             url: url,
    //             method: 'GET',
    //             success: function(data) {
    //                 $('#content').html($(data).find('#content').html());
    //             },
    //             error: function(xhr) {
    //                 console.error('Error loading page', xhr);
    //             }
    //         });
    //     };
    //
    //     // Load the initial content
    //     var initialUrl = window.location.pathname;
    //     if (initialUrl !== '/') {
    //         console.log('Initial load:', initialUrl);
    //         $.ajax({
    //             url: initialUrl,
    //             method: 'GET',
    //             success: function(data) {
    //                 $('#content').html($(data).find('#content').html());
    //             },
    //             error: function(xhr) {
    //                 console.error('Error loading initial page', xhr);
    //             }
    //         });
    //     }
    // });
</script>
</body>

</html>
<?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/layouts/vertical.blade.php ENDPATH**/ ?>