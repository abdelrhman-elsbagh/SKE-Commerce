<!-- ========== Left Sidebar Start ========== -->
<div class="leftside-menu">

    <!-- Brand Logo Light -->
    <a href="<?php echo e(route('any', 'index')); ?>" class="logo logo-light nav-link">
        <span class="logo-lg">
            <img src="/images/logo.png" alt="logo">
        </span>
        <span class="logo-sm">
            <img src="/images/logo-sm.png" alt="small logo">
        </span>
    </a>

    <!-- Brand Logo Dark -->
    <a href="<?php echo e(route('any', 'index')); ?>" class="logo logo-dark nav-link">
        <span class="logo-lg">
            <img src="/images/logo-dark.png" alt="logo">
        </span>
        <span class="logo-sm">
            <img src="/images/logo-sm.png" alt="small logo">
        </span>
    </a>

    <!-- Sidebar Hover Menu Toggle Button -->
    <div class="button-sm-hover" data-bs-toggle="tooltip" data-bs-placement="right" title="Show Full Sidebar">
        <i class="ri-checkbox-blank-circle-line align-middle"></i>
    </div>

    <!-- Full Sidebar Menu Close Button -->
    <div class="button-close-fullsidebar">
        <i class="ri-close-fill align-middle"></i>
    </div>

    <!-- Sidebar -left -->
    <div class="h-100" id="leftside-menu-container" data-simplebar>
        <!-- Leftbar User -->
        <div class="leftbar-user">
            <a href="<?php echo e(route('second', ['pages', 'profile'])); ?>" class="nav-link">
                <img src="/images/users/avatar-1.jpg" alt="user-image" height="42" class="rounded-circle shadow-sm">
                <span class="leftbar-user-name mt-2">Tosha Minner</span>
            </a>
        </div>

        <!--- Sidemenu -->
        <ul class="side-nav">

            <li class="side-nav-title">Navigation</li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarDashboards" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link nav-link">
                    <i class="ri-home-4-line"></i>
                    <span class="badge bg-success float-end">2</span>
                    <span> Dashboards </span>
                </a>
                <div class="collapse" id="sidebarDashboards">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('any', 'analytics')); ?>" class="nav-link">Analytics</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('any', 'index')); ?>" class="nav-link">Ecommerce</a>
                        </li>
                    </ul>
                </div>
            </li>










            <li class="side-nav-item">
                <a href="<?php echo e(route('second', ['apps', 'chat'])); ?>" class="side-nav-link nav-link">
                    <i class="ri-message-3-line"></i>
                    <span> Chat </span>
                </a>
            </li>












































































































































































































































































































































            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarCategories" aria-expanded="false" aria-controls="sidebarCategories" class="side-nav-link nav-link">
                    <i class="ri-folder-line"></i>
                    <span> Categories </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarCategories">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('categories.index')); ?>" class="nav-link">All Categories</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('categories.create')); ?>" class="nav-link">Create Category</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarItems" aria-expanded="false" aria-controls="sidebarItems" class="side-nav-link nav-link">
                    <i class="ri-file-list-line"></i>
                    <span> Items </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarItems">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('items.index')); ?>" class="nav-link">All Items</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('items.create')); ?>" class="nav-link">Create Item</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarUsers" aria-expanded="false" aria-controls="sidebarUsers" class="side-nav-link nav-link">
                    <i class="ri-user-line"></i>
                    <span> Users </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarUsers">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('users.index')); ?>" class="nav-link">All Users</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('users.create')); ?>" class="nav-link">Create User</a>
                        </li>
                    </ul>
                </div>
            </li>


            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarPlans" aria-expanded="false" aria-controls="sidebarPlans" class="side-nav-link nav-link">
                    <i class="ri-calendar-check-line"></i>
                    <span> Plans </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarPlans">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('plans.index')); ?>" class="nav-link">All Plans</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('plans.create')); ?>" class="nav-link">Create Plan</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarSubscriptions" aria-expanded="false" aria-controls="sidebarSubscriptions" class="side-nav-link nav-link">
                    <i class="ri-coin-line"></i>
                    <span> Subscriptions </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarSubscriptions">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('subscriptions.index')); ?>" class="nav-link">All Subscriptions</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('subscriptions.create')); ?>" class="nav-link">Create Subscription</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarTags" aria-expanded="false" aria-controls="sidebarTags" class="side-nav-link nav-link">
                    <i class="ri-price-tag-3-line"></i>
                    <span> Tags </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarTags">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('tags.index')); ?>" class="nav-link">All Tags</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('tags.create')); ?>" class="nav-link">Create Tag</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarUserWallets" aria-expanded="false" aria-controls="sidebarUserWallets" class="side-nav-link nav-link">
                    <i class="ri-wallet-line"></i>
                    <span> User Wallets </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarUserWallets">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('user-wallets.index')); ?>" class="nav-link">View All</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user-wallets.create')); ?>" class="nav-link">Create New</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarBusinessClientWallets" aria-expanded="false" aria-controls="sidebarBusinessClientWallets" class="side-nav-link nav-link">
                    <i class="ri-wallet-3-line"></i>
                    <span> Business Client Wallets </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarBusinessClientWallets">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('business-client-wallets.index')); ?>" class="nav-link">View All</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('business-client-wallets.create')); ?>" class="nav-link">Create New</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a href="<?php echo e(route('sliders.index')); ?>" class="side-nav-link nav-link">
                    <i class="ri-slideshow-line"></i>
                    <span> Sliders </span>
                </a>
            </li>


            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarIcons" aria-expanded="false" aria-controls="sidebarIcons" class="side-nav-link nav-link">
                    <i class="ri-service-line"></i>
                    <span> Icons </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarIcons">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('second', ['icons', 'remixicons'])); ?>" class="nav-link">Remix Icons</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('second', ['icons', 'bootstrapicons'])); ?>" class="nav-link">Bootstrap Icons</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="side-nav-item">
                <a href="<?php echo e(route('purchase-requests.index')); ?>" class="side-nav-link">
                    <i class="ri-file-list-line"></i>
                    <span> Purchase Requests </span>
                </a>
            </li>

            <li class="side-nav-item">
                <a href="<?php echo e(route('orders.index')); ?>" class="side-nav-link">
                    <i class="ri-shopping-cart-line"></i>
                    <span> Orders </span>
                </a>
            </li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarPaymentMethods" aria-expanded="false" aria-controls="sidebarPaymentMethods" class="side-nav-link nav-link">
                    <i class="ri-money-dollar-box-line"></i>
                    <span> Payment Methods </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarPaymentMethods">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('payment-methods.index')); ?>" class="nav-link">All Payment Methods</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('payment-methods.create')); ?>" class="nav-link">Create Payment Method</a>
                        </li>
                    </ul>
                </div>
            </li>



            <li class="side-nav-item">
                <a href="<?php echo e(route('configs.edit')); ?>" class="side-nav-link">
                    <i class="ri-settings-3-line"></i>
                    <span> Configuration </span>
                </a>
            </li>


























































































































































































































        </ul>
        <!--- End Sidemenu -->

        <div class="clearfix"></div>
    </div>
</div>
<!-- ========== Left Sidebar End ========== -->
<?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/layouts/shared/left-sidebar.blade.php ENDPATH**/ ?>