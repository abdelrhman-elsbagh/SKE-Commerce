<?php $__env->startSection('title', 'Ske E-Commerce'); ?>

<?php $__env->startSection('content'); ?>
    <main class="page-main">
        <div class="uk-grid" data-uk-grid>
            <div class="uk-width-3-3@l">
                <div class="widjet --profile">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Profile</h3>
                    </div>
                    <div class="widjet__body">
                        <div class="user-info">
                            <div class="user-info__avatar">
                                <img src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="profile">
                            </div>
                            <div class="user-info__box">
                                <div class="user-info__title"><?php echo e($businessClient->name); ?></div>
                                <div class="user-info__text"><?php echo e($businessClient->address); ?>, Member since <?php echo e($businessClient->created_at->format('F Y')); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="widjet --bio">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Bio</h3>
                    </div>
                    <div class="widjet__body"><span><?php echo e($businessClient->bio ?? 'No bio available.'); ?></span></div>
                </div>
                <div class="widjet --activity">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Recent Activity</h3>
                    </div>
                    <div class="widjet__body">
                        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="widjet-game" style="margin-bottom: 20px;">
                                <div class="widjet-game__media">
                                    <?php if($subscription->plan->getFirstMediaUrl('images')): ?>
                                        <a href="<?php echo e(route('plan.show', ['id' => $subscription->plan->id])); ?>">
                                            <img src="<?php echo e($subscription->plan->getFirstMediaUrl('images')); ?>" alt="<?php echo e($subscription->plan->name); ?>">
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="widjet-game__info">
                                    <a class="widjet-game__title" href="<?php echo e(route('plan.show', ['id' => $subscription->plan->id])); ?>"> <?php echo e($subscription->plan->name); ?></a>
                                    <div class="widjet-game__record">Subscription ID: #<?php echo e($subscription->id); ?></div>
                                    <div class="widjet-game__record">Price: <?php echo e($subscription->plan->price); ?> USD</div>
                                    <div class="widjet-game__last-played">Subscribed on <?php echo e($subscription->start_date->format('d M, Y')); ?></div>
                                    <div class="widjet-game__record">Ends on: <?php echo e($subscription->end_date->format('d M, Y')); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="widjet --purchase-requests">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Purchase Requests</h3>
                    </div>
                    <div class="widjet__body">
                        <?php $__currentLoopData = $purchaseRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="widjet-game" style="margin-bottom: 20px;">
                                <div class="widjet-game__media">
                                    <?php if($request->getFirstMediaUrl('images')): ?>
                                        <a href="#">
                                            <img src="<?php echo e($request->getFirstMediaUrl('images')); ?>" alt="Purchase Request Image">
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="widjet-game__info">
                                    <div class="widjet-game__title">Request ID: <?php echo e($request->id); ?></div>
                                    <div class="widjet-game__record"><?php echo e($request->amount); ?> USD</div>
                                    <div class="widjet-game__last-played">Status: <?php echo e(ucfirst($request->status)); ?></div>
                                    <div class="widjet-game__last-played">Requested on <?php echo e($request->created_at->format('d M, Y')); ?></div>
                                    <div class="widjet-game__description"><?php echo e($request->notes); ?></div>
                                </div>
                            </div>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php if(session('success')): ?>
        <?php $__env->startPush('scripts'); ?>
            <script>
                toastr.success("<?php echo e(session('success')); ?>");
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/front/business_profile.blade.php ENDPATH**/ ?>