<?php $__env->startSection('title', 'Ske E-Commerce'); ?>

<?php $__env->startSection('content'); ?>
    <main class="page-main">
        <div class="uk-width-4-5@l uk-width-3-3@m uk-width-3-3@s uk-margin-auto">
            <h3 class="uk-text-lead">Recommended & Featured</h3>
            <div class="js-recommend">
                <div class="swiper">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="recommend-slide">
                                    <div class="tour-slide__box">
                                        <a href="<?php echo e(route('home')); ?>">
                                            <?php if($slider->getFirstMediaUrl('images')): ?>
                                                <img src="<?php echo e($slider->getFirstMediaUrl('images')); ?>" alt="<?php echo e($slider->name); ?>" style="width: 100%">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/img/default-slider.jpg')); ?>" alt="Default Slider" style="width: 100%">
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="swipper-nav">
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-button-next"></div>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>

        </div>

        <div class="uk-grid uk-child-width-1-6@xl uk-child-width-1-5@m uk-child-width-1-3@s uk-grid-small" data-uk-grid>
            <?php $__currentLoopData = $categorizedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="uk-width-1-1">
                    <h3><?php echo e($categoryName); ?></h3>
                    <div class="uk-grid uk-child-width-1-6@xl uk-child-width-1-5@m uk-child-width-1-3@s uk-grid-small">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="uk-width-1-6@xl uk-width-1-5@m uk-width-1-3@s" style="margin-top: 15px;">
                                <div class="game-card <?php echo e($item->status == 'inactive' ? 'inactive' : ''); ?>">
                                    <div class="game-card__box">
                                        <div class="game-card__media">
                                            <a href="<?php echo e($item->status == 'active' ? route('item.show', ['id' => $item->id]) : '#'); ?>" class="<?php echo e($item->status == 'inactive' ? 'disabled-link' : ''); ?>">
                                                <?php if($item->getFirstMediaUrl('images')): ?>
                                                    <img src="<?php echo e($item->getFirstMediaUrl('images')); ?>" alt="<?php echo e($item->name); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('assets/img/default-game.jpg')); ?>" alt="Default Image">
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                        <div class="game-card__info">
                                            <a class="game-card__title" href="<?php echo e($item->status == 'active' ? route('item.show', ['id' => $item->id]) : '#'); ?>"><?php echo e($item->name); ?></a>
                                            <?php if($item->title_type != 'default'): ?>
                                                <div class="card-tag <?php echo e($item->title_type == 'discount' ? 'card-tag-discount' : ($item->title_type == 'new' ? 'card-tag-new' : '')); ?>"><?php echo e($item->title); ?></div>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $item->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="game-card__genre"><?php echo e($tag->name); ?><?php echo e(!$loop->last ? ' - ' : ''); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
    <?php if(session('success')): ?>
        <?php $__env->startPush('scripts'); ?>
            <script>
                toastr.success("<?php echo e(session('success')); ?>");
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>

    <style>
        .card-tag {
            text-align: center;
            width: 110px;
            rotate: -45deg;
            position: absolute;
            top: 12px;
            left: -20px;
            padding: 9px 20px;
            font-size: 14px;
            font-weight: bold;
            color: white;
            border-radius: 2px;
            max-height: 47px;
        }
        .card-tag-discount {
            background-color: red;
        }
        .card-tag-new {
            background-color: yellow;
            color: #2d2d2d;
        }
        .game-card__box {
            position: relative;
            overflow: hidden;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/front/index.blade.php ENDPATH**/ ?>