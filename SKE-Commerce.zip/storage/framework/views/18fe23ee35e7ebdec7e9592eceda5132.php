<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.css'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">User Wallet Details</h4>
                        <table class="table table-bordered">
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($wallet->id); ?></td>
                            </tr>
                            <tr>
                                <th>User ID</th>
                                <td><?php echo e($wallet->user_id); ?></td>
                            </tr>
                            <tr>
                                <th>Balance</th>
                                <td><?php echo e($wallet->balance); ?></td>
                            </tr>
                        </table>
                        <a href="<?php echo e(route('user-wallets.index')); ?>" class="btn btn-primary">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'node_modules/jquery-toast-plugin/dist/jquery.toast.min.js'
    ]); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['page_title' => 'User Wallet Details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/admin/user_wallet/show.blade.php ENDPATH**/ ?>