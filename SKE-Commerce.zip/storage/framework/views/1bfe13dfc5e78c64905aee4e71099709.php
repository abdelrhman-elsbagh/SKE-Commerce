<?php $__env->startSection('title', 'Ske E-Commerce'); ?>

<?php $__env->startSection('content'); ?>
    <main class="page-main">
        <div class="uk-grid" data-uk-grid>
            <div class="uk-width-2-3@l">
                <div class="widjet --wallet">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Wallet</h3>
                    </div>
                    <div class="widjet__body">
                        <div class="wallet-info">
                            <div class="wallet-value"><?php echo e(number_format($wallet->balance, 2)); ?> USD</div>
                            <div class="wallet-label">Available</div>
                        </div>
                    </div>
                </div>
                <div class="widjet --purchase-requests">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Recent Purchase Requests</h3>
                    </div>
                    <div class="widjet__body">
                        <ul class="activities-list">
                            <?php $__currentLoopData = $purchaseRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="activities-item">
                                    <div class="activities-item__logo">
                                        <img src="<?php echo e($request->getFirstMediaUrl('images') ?? asset('assets/img/default-image.jpg')); ?>" alt="image">
                                    </div>
                                    <div class="activities-item__info">
                                        <div class="activities-item__title"><?php echo e($request->notes); ?></div>
                                        <div class="activities-item__date"><?php echo e($request->created_at->format('d M, Y')); ?></div>
                                    </div>
                                    <div class="activities-item__price">$<?php echo e(number_format($request->amount, 2)); ?></div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-3@l">
                <div class="widjet --payment-method">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Payment Method</h3>
                    </div>
                    <div class="widjet__body">
                        <div class="payment-card">
                            <div class="payment-card__head">
                                <div class="payment-card__chip">
                                    <img src="<?php echo e(asset('assets/img/payment-card-chip.svg')); ?>" alt="chip">
                                </div>
                                <div class="payment-card__logo">
                                    <img src="<?php echo e(asset('assets/img/payment-card-logo.svg')); ?>" alt="logo">
                                </div>
                            </div>
                            <div class="payment-card__number">Direct Payment</div>
                        </div>
                    </div>
                </div>
                <div class="widjet --activities">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Recent Orders</h3>
                    </div>
                    <div class="widjet__body">
                        <ul class="activities-list">
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $order->subItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderSubItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $subItem = $orderSubItem->subItem;
                                        $item = $subItem->item;
                                    ?>
                                    <li class="activities-item">
                                        <div class="activities-item__logo">
                                            <a href="<?php echo e(route('item.show', ['id' => $item->id])); ?>">
                                                <?php if($item->getFirstMediaUrl('images')): ?>
                                                    <img src="<?php echo e($item->getFirstMediaUrl('images')); ?>" alt="<?php echo e($item->name); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('assets/img/default-image.jpg')); ?>" alt="Default Image">
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                        <div class="activities-item__info">
                                            <a class="activities-item__title" href="<?php echo e(route('item.show', ['id' => $item->id])); ?>">
                                                <?php echo e($item->name); ?>

                                            </a>
                                            <div class="activities-item__date"><?php echo e($order->created_at->format('d M, Y')); ?></div>
                                        </div>
                                        <div class="activities-item__price">$<?php echo e(number_format($orderSubItem->price, 2)); ?></div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/front/wallet.blade.php ENDPATH**/ ?>