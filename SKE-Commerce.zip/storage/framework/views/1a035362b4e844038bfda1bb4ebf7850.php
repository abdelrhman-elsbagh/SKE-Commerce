<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>TeamHost - Join now and play mighty games!</title>
    <meta content="Templines" name="author">
    <meta content="TeamHost" name="description">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="HandheldFriendly" content="true">
    <meta name="format-detection" content="telephone=no">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/libs.min.css">
    <link rel="stylesheet" href="assets/css/main.css">


    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Marcellus&display=swap" rel="stylesheet">


</head>

<body class="page-store">

    <input id="toggle" type="checkbox">
    <script type="text/javascript">
        document.getElementById("toggle").addEventListener("click", function() {
            document.getElementsByTagName('body')[0].classList.toggle("dark-theme");
        });

    </script>

    <!-- Loader-->
    <div id="page-preloader">
        <div class="preloader-1">
            <div class="loader-text">Loading</div>
            <span class="line line-1"></span>
            <span class="line line-2"></span>
            <span class="line line-3"></span>
            <span class="line line-4"></span>
            <span class="line line-5"></span>
            <span class="line line-6"></span>
            <span class="line line-7"></span>
            <span class="line line-8"></span>
            <span class="line line-9"></span>
        </div>

    </div>
    <!-- Loader end-->


    <div class="page-wrapper">
        <header class="page-header">
            <div class="page-header__inner">
                <div class="page-header__sidebar">
                    <div class="page-header__menu-btn"><button class="menu-btn ico_menu is-active"></button></div>
                    <div class="page-header__logo"><img src="assets/img/logo.png" alt="logo"><span class="page-header__logo_text">TEAMHOST</span></div>
                </div>
                <div class="page-header__content">
                    <div class="page-header__search">
                        <div class="search">
                            <div class="search__input"><i class="ico_search"></i><input type="search" name="search" placeholder="Search"></div>
                            <div class="search__btn"><button type="button"><i class="ico_microphone"></i></button></div>
                        </div>
                    </div>
                    <div class="page-header__action">
                        <a class="action-btn" href="06_chats.html"><i class="ico_message"></i><span class="animation-ripple-delay1"></span></a>
                        <a class="action-btn" href="07_friends.html"><i class="ico_notification"></i><span class="animation-ripple-delay2"></span></a>
                        <a class="profile" href="08_wallet.html"><img src="assets/img/profile.png" alt="profile"></a>
                    </div>
                </div>
            </div>
        </header>
        <div class="page-content">
            <aside class="sidebar is-show" id="sidebar">
                <div class="sidebar-box">
                    <ul class="uk-nav">
                        <li><a href="03_home.html"><i class="ico_home"></i><span>Home</span></a></li>
                        <li class="uk-nav-header">Account</li>
                        <li><a href="04_profile.html"><i class="ico_profile"></i><span>Profile</span></a></li>
                        <li><a href="05_favourites.html"><i class="ico_favourites"></i><span>Favourites</span><span class="count">15</span></a></li>
                        <li><a href="06_chats.html"><i class="ico_chats"></i><span>Chats</span></a></li>
                        <li><a href="07_friends.html"><i class="ico_friends"></i><span>Friends</span></a></li>
                        <li><a href="08_wallet.html"><i class="ico_wallet"></i><span>Wallet</span></a></li>
                        <li class="uk-nav-header">Main</li>
                        <li class="uk-active"><a href="09_games-store.html"><i class="ico_store"></i><span>Store</span></a></li>
                        <li><a href="11_market.html"><i class="ico_market"></i><span>Market</span></a></li>
                        <li><a href="12_streams.html"><i class="ico_streams"></i><span>Streams</span></a></li>
                        <li><a href="13_community.html"><i class="ico_community"></i><span>Community</span></a></li>
                        <li class="uk-nav-header">Support</li>
                        <li><a href="#modal-report" data-uk-toggle><i class="ico_report"></i><span>Report</span></a></li>
                        <li><a href="#modal-help" data-uk-toggle><i class="ico_help"></i><span>Help</span></a></li>
                    </ul>
                </div>
            </aside>
            <main class="page-main">
                <div class="widjet --filters">
                    <div class="widjet__head">
                        <h3 class="uk-text-lead">Games Store</h3>
                    </div>
                    <div class="widjet__body">
                        <div class="uk-grid uk-child-width-1-6@xl uk-child-width-1-3@l uk-child-width-1-2@s uk-flex-middle uk-grid-small" data-uk-grid>
                            <div class="uk-width-1-1">
                                <div class="search">
                                    <div class="search__input"><i class="ico_search"></i><input type="search" name="search" placeholder="Search"></div>
                                    <div class="search__btn"><button type="button"><i class="ico_microphone"></i></button></div>
                                </div>
                            </div>
                            <div><select class="js-select">
                                    <option value="">Sort By: Price</option>
                                    <option value="Price 1">Price 1</option>
                                    <option value="Price 2">Price 2</option>
                                    <option value="Price 3">Price 3</option>
                                </select></div>
                            <div><select class="js-select">
                                    <option value="">Category: Strategy</option>
                                    <option value="Category 1">Category 1</option>
                                    <option value="Category 2">Category 2</option>
                                    <option value="Category 3">Category 3</option>
                                </select></div>
                            <div><select class="js-select">
                                    <option value="">Platform: All</option>
                                    <option value="Platform 1">Platform 1</option>
                                    <option value="Platform 2">Platform 2</option>
                                    <option value="Platform 3">Platform 3</option>
                                </select></div>
                            <div><select class="js-select">
                                    <option value=""># of Players: All</option>
                                    <option value="Platform 1">Platform 1</option>
                                    <option value="Platform 2">Platform 2</option>
                                    <option value="Platform 3">Platform 3</option>
                                </select></div>
                            <div>
                                <div class="price-range"><label>Price</label><input class="uk-range" type="range" value="2" min="0" max="10" step="0.1"></div>
                            </div>
                            <div class="uk-text-right"><a href="#!">25 items</a></div>
                        </div>
                    </div>
                </div>
                <div class="uk-grid uk-child-width-1-6@xl uk-child-width-1-4@l uk-child-width-1-3@s uk-flex-middle uk-grid-small" data-uk-grid>
                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-1.jpg" alt="Struggle of Rivalry" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Struggle of Rivalry</a>
                                    <div class="game-card__genre">Shooter / Platformer</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.8</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$4.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-2.jpg" alt="Hunt of Duplicity" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Hunt of Duplicity</a>
                                    <div class="game-card__genre">Action / Adventure</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.6</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$9.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-3.jpg" alt="Journey and Dimension" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Journey and Dimension</a>
                                    <div class="game-card__genre">Survival / Strategy</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.7</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$13.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-4.jpg" alt="Reckoning and Freedom" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Reckoning and Freedom</a>
                                    <div class="game-card__genre">Strategy</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.1</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$49.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-5.jpg" alt="Pillage of Redemption" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Pillage of Redemption</a>
                                    <div class="game-card__genre">Survival / Strategy</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.7</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$13.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-6.jpg" alt="Invade of Heroes" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Invade of Heroes</a>
                                    <div class="game-card__genre">Strategy</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.1</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$49.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-7.jpg" alt="Genesis and Renegade" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Genesis and Renegade</a>
                                    <div class="game-card__genre">Shooter / Platformer</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.8</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$4.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-8.jpg" alt="Barbarians and Truth" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Barbarians and Truth</a>
                                    <div class="game-card__genre">Shooter / Platformer</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.8</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$4.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-9.jpg" alt="Fire and Demons" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Fire and Demons</a>
                                    <div class="game-card__genre">Shooter / Platformer</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.8</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$4.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-6.jpg" alt="Strife of Retribution" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Strife of Retribution</a>
                                    <div class="game-card__genre">Strategy</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.1</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$49.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-10.jpg" alt="Crimson Resurrection" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Crimson Resurrection</a>
                                    <div class="game-card__genre">Shooter / Platformer</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.8</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$4.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div>
                        <div class="game-card">
                            <div class="game-card__box">
                                <div class="game-card__media"><a href="10_game-profile.html"><img src="assets/img/game-4.jpg" alt="Bio Armada" /></a></div>
                                <div class="game-card__info"><a class="game-card__title" href="10_game-profile.html"> Bio Armada</a>
                                    <div class="game-card__genre">Strategy</div>
                                    <div class="game-card__rating-and-price">
                                        <div class="game-card__rating"><span>4.1</span><i class="ico_star"></i></div>
                                        <div class="game-card__price"><span>$49.99 </span></div>
                                    </div>
                                    <div class="game-card__bottom">
                                        <div class="game-card__platform"><i class="ico_windows"></i><i class="ico_apple"></i></div>
                                        <div class="game-card__users">
                                            <ul class="users-list">
                                                <li><img src="assets/img/user-1.png" alt="user" /></li>
                                                <li><img src="assets/img/user-2.png" alt="user" /></li>
                                                <li><img src="assets/img/user-3.png" alt="user" /></li>
                                                <li><img src="assets/img/user-4.png" alt="user" /></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>






                </div>
            </main>
        </div>
    </div>
    <div class="page-modals">
        <div class="uk-flex-top" id="modal-report" data-uk-modal>
            <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical"><button class="uk-modal-close-default" type="button" data-uk-close></button>
                <h2 class="uk-modal-title">Report</h2>
                <form class="uk-form-stacked" action="#">
                    <div class="uk-margin">
                        <div class="uk-form-label">Subject</div>
                        <div class="uk-form-controls"><select class="js-select">
                                <option value="">Choose Subject</option>
                                <option value="Subject 1">Subject 1</option>
                                <option value="Subject 2">Subject 2</option>
                                <option value="Subject 3">Subject 3</option>
                            </select></div>
                    </div>
                    <div class="uk-margin">
                        <div class="uk-form-label">Details</div>
                        <div class="uk-form-controls"><textarea class="uk-textarea" name="details" placeholder="Try to include all details..."></textarea></div>
                        <div class="uk-form-controls uk-margin-small-top">
                            <div data-uk-form-custom><input type="file"><button class="uk-button uk-button-default" type="button" tabindex="-1"><i class="ico_attach-circle"></i><span>Attach File</span></button></div>
                        </div>
                    </div>
                    <div class="uk-margin">
                        <div class="uk-grid uk-flex-right" data-uk-grid>
                            <div><button class="uk-button uk-button-small uk-button-link">Cancel</button></div>
                            <div><button class="uk-button uk-button-small uk-button-danger">Submit</button></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="uk-flex-top" id="modal-help" data-uk-modal>
            <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical"><button class="uk-modal-close-default" type="button" data-uk-close></button>
                <h2 class="uk-modal-title">Help</h2>
                <div class="search">
                    <div class="search__input"><i class="ico_search"></i><input type="search" name="search" placeholder="Search"></div>
                    <div class="search__btn"><button type="button"><i class="ico_microphone"></i></button></div>
                </div>
                <div class="uk-margin-small-left uk-margin-small-bottom uk-margin-medium-top">
                    <h4>Popular Q&A</h4>
                    <ul>
                        <li><img src="assets/img/svgico/clipboard-text.svg" alt="icon"><span>How to Upload Your Developed Game</span></li>
                        <li><img src="assets/img/svgico/clipboard-text.svg" alt="icon"><span>How to Go Live Stream</span></li>
                        <li><img src="assets/img/svgico/clipboard-text.svg" alt="icon"><span>Get in touch with the Creator Support Team</span></li>
                    </ul>
                    <ul>
                        <li><a href="#!">browse all articles</a></li>
                        <li><a href="#!">Send Feedback</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/libs.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
<?php /**PATH /home/abdel/Downloads/Attex_Laravel_v1.0.0/SKE-Commerce/resources/views/front/index.blade.php ENDPATH**/ ?>
